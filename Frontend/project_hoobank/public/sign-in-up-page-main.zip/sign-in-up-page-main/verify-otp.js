document.addEventListener("DOMContentLoaded", function () {
    const verifyOtpForm = document.getElementById("verify-otp-form");
    const message = document.getElementById("message");
    const email = localStorage.getItem("email");

    if (!email) {
        message.textContent = "Erreur : Aucun email trouvé.";
        return;
    }

    verifyOtpForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const otp = document.getElementById("otp").value.trim();

        if (!otp) {
            message.textContent = "Veuillez entrer le code OTP.";
            return;
        }

        try {
            const response = await fetch("http://localhost:5000/auth/verify-otp", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, otp })
            });

            const result = await response.json();
            message.textContent = result.message;

            if (response.ok) {
                localStorage.removeItem("email");
                window.location.href = "http://localhost:5174";

            } else {
                message.textContent = "Code incorrect.";
            }
        } catch (error) {
            message.textContent = "Erreur de vérification.";
        }
    });
});
