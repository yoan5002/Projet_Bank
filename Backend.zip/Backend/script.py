import sys
sys.stdout.reconfigure(encoding='utf-8')

print("Hello depuis Python ! ")
